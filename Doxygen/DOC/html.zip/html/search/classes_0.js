var searchData=
[
  ['definition',['definition',['../struct_operation_space_1_1definition.html',1,'OperationSpace']]]
];
