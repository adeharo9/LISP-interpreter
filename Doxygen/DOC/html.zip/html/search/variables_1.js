var searchData=
[
  ['exp',['exp',['../struct_operation_space_1_1definition.html#af50bcfd1fc8f83f8351ed5ba669c6fc7',1,'OperationSpace::definition']]]
];
