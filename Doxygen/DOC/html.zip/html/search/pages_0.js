var searchData=
[
  ['pro2_20_2d_20práctica_20qt16_2d17_3a_20calculadora_20de_20expresiones_20aritméticas',['PRO2 - Práctica QT16-17: Calculadora de expresiones aritméticas',['../index.html',1,'']]]
];
