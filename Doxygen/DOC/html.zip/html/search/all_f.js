var searchData=
[
  ['tail',['tail',['../class_primitive_operation_space.html#a08ecc4d0207c93ab245f05732e0024c3',1,'PrimitiveOperationSpace']]],
  ['type',['type',['../class_expression.html#a2c094b93c4863b1f851ea2136aae9612',1,'Expression']]]
];
