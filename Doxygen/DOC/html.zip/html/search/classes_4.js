var searchData=
[
  ['primitiveoperationspace',['PrimitiveOperationSpace',['../class_primitive_operation_space.html',1,'']]]
];
