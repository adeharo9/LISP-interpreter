var searchData=
[
  ['variablespace',['VariableSpace',['../class_variable_space.html#aa5cc75308d063873297bc15dbb3df9b0',1,'VariableSpace::VariableSpace()'],['../class_variable_space.html#a61593b2566ddf90eb391bfad68c1caf0',1,'VariableSpace::VariableSpace(const VariableSpace &amp;varSpace)']]]
];
