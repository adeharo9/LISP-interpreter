var searchData=
[
  ['variablespace',['VariableSpace',['../class_variable_space.html',1,'']]]
];
